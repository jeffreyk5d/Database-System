<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $servername = "localhost";
            $username = "company";
            $password = "password";
            $db_name = "company2.0";
            
            $con = mysqli_connect($servername,$username,$password,$db_name);
            
            if(!$con){
                echo '錯誤<\br>';
                exit(1);
            }
            else{
                echo '成功';
            }
            
            
            
            echo "<table border='1'>";
            $result = mysqli_query($con, "SELECT * FROM employee;");
                while($row = mysqli_fetch_array($result)){
                    echo"<tr>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td>" . $row['ssn'] . "</td>";
                    echo "<td>" . $row['super_ssn'] . "</td>";
                    echo "<td>" . $row['dno'] . "</td>";
                    echo "</tr>";
                }
                
                
             echo "</table>";
             echo "<table border='1'>";
             
             
             $result = mysqli_query($con, "SELECT * FROM department;");
             
             
             while($row = mysqli_fetch_array($result)){
                    echo"<tr>";
                    echo "<td>" . $row['dname'] . "</td>";
                    echo "<td>" . $row['dno'] . "</td>";
                    echo "</tr>";
                }
                
                
            echo "</table>";
            mysqli_close($con);
        ?>
    </body>
</html>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body style="font-size:30px;" align="center">
        <p style="font-size:30px;" align="center"><a href="company5.html" target="0">回索引</a><br>
        <?php
        $act= $_POST['company_info'];
        
        $department="department";
        $dependent="dependent";
        $dept_locations="dept_locations";
        $employee="employee";
        $project="project";
        $works_on="works_on";
        
        echo "$act";
        if($act==$department){
            
            $servername = "localhost";
            $username = "root";
            $password = "";
            $db_name = "company";
            
            $con = mysqli_connect($servername,$username,$password,$db_name);
            

            
            
            echo "<table border='1'>";
            $result = mysqli_query($con, "SELECT * FROM department;");
                echo "<td>".'<b>Dname<b>';    "</td>";
                echo "<td>".'<b>Dnumber<b>';    "</td>";
                echo "<td>".'<b>Mgr_ssn<b>';    "</td>";
                echo "<td>".'<b>Mgr_start_date<b>';    "</td>";
                while($row = mysqli_fetch_array($result)){
                    echo"<tr>";
                    echo "<td>" . $row['Dname'] . "</td>";
                    echo "<td>" . $row['Dnumber'] . "</td>";
                    echo "<td>" . $row['Mgr_ssn'] . "</td>";
                    echo "<td>" . $row['Mgr_start_date'] . "</td>";
                    echo "</tr>";
                }
                
                
             echo "</table>";
             
            mysqli_close($con);
        }elseif($act==$dependent){
            $servername = "localhost";
            $username = "root";
            $password = "";
            $db_name = "company";
            
            $con = mysqli_connect($servername,$username,$password,$db_name);
            

            
            
            
            echo "<table border='1'>";
            $result = mysqli_query($con, "SELECT * FROM dependent;");
                echo "<td>".'<b>Essn<b>';    "</td>";
                echo "<td>".'<b>Dependent_name<b>';    "</td>";
                echo "<td>".'<b>Sex<b>';    "</td>";
                echo "<td>".'<b>Bdate<b>';    "</td>";
                echo "<td>".'<b>Relationship<b>';    "</td>";                
                while($row = mysqli_fetch_array($result)){
                    echo"<tr>";
                    echo "<td>" . $row['Essn'] . "</td>";
                    echo "<td>" . $row['Dependent_name'] . "</td>";
                    echo "<td>" . $row['Sex'] . "</td>";
                    echo "<td>" . $row['Bdate'] . "</td>";
                    echo "<td>" . $row['Relationship'] . "</td>";                 
                    echo "</tr>";
                }
                
                
             echo "</table>";
             
            mysqli_close($con);
        }elseif($act==$dept_locations){
            $servername = "localhost";
            $username = "root";
            $password = "";
            $db_name = "company";
            
            $con = mysqli_connect($servername,$username,$password,$db_name);
            

            
            
            
            echo "<table border='1'>";
            $result = mysqli_query($con, "SELECT * FROM dept_locations;");
            echo "<td>".'<b>Dno<b>';    "</td>";
            echo "<td>".'<b>Dlocation<b>';    "</td>";
            while($row = mysqli_fetch_array($result)){
                    echo"<tr>";
                    
                    echo "<td>" . $row['Dno'] . "</td>";
                    echo "<td>" . $row['Dlocation'] . "</td>";                    
                    echo "</tr>";
                }
                
                
             echo "</table>";
             
            mysqli_close($con);
        }elseif ($act==$employee) {
            $servername = "localhost";
            $username = "root";
            $password = "";
            $db_name = "company";
            
            $con = mysqli_connect($servername,$username,$password,$db_name);
            

            
            
            echo "<table border='1'>";
            $result = mysqli_query($con, "SELECT * FROM employee;");
                echo "<td>".'<b>Fname<b>';    "</td>";
                echo "<td>".'<b>Minit<b>';    "</td>";
                echo "<td>".'<b>Lname<b>';    "</td>";
                echo "<td>".'<b>Ssn<b>';    "</td>";
                echo "<td>".'<b>Bdate<b>';    "</td>";
                echo "<td>".'<b>Address<b>';    "</td>";
                echo "<td>".'<b>Sex<b>';    "</td>";
                echo "<td>".'<b>Salary<b>';    "</td>";
                echo "<td>".'<b>Super_ssn<b>';    "</td>";
                echo "<td>".'<b>Dno<b>';    "</td>";
                while($row = mysqli_fetch_array($result)){
                    echo"<tr>";
                    echo "<td>" . $row['Fname'] . "</td>";
                    echo "<td>" . $row['Minit'] . "</td>";
                    echo "<td>" . $row['Lname'] . "</td>";
                    echo "<td>" . $row['Ssn'] . "</td>";
                    echo "<td>" . $row['Bdate'] . "</td>";
                    echo "<td>" . $row['Address'] . "</td>";
                    echo "<td>" . $row['Sex'] . "</td>";
                    echo "<td>" . $row['Salary'] . "</td>";
                    echo "<td>" . $row['Super_ssn'] . "</td>";
                    echo "<td>" . $row['Dno'] . "</td>";
                    echo "</tr>";
                }
                
                
             echo "</table>";
             
            mysqli_close($con);
        }elseif($act==$project){
            $servername = "localhost";
            $username = "root";
            $password = "";
            $db_name = "company";
            
            $con = mysqli_connect($servername,$username,$password,$db_name);
            
    
            
            
            echo "<table border='1'>";
            $result = mysqli_query($con, "SELECT * FROM project;");
            
                echo "<td>".'<b>Pname<b>';    "</td>";
                echo "<td>".'<b>Pnumber<b>';    "</td>";
                echo "<td>".'<b>Plocation<b>';    "</td>";
                echo "<td>".'<b>Dnum<b>';    "</td>";
                while($row = mysqli_fetch_array($result)){
                    echo"<tr>";
                    echo "<td>" . $row['Pname'] . "</td>";
                    echo "<td>" . $row['Pnumber'] . "</td>";
                    echo "<td>" . $row['Plocation'] . "</td>";
                    echo "<td>" . $row['Dnum'] . "</td>";
                    echo "</tr>";
                }
                
                
             echo "</table>";
             
            mysqli_close($con);
        }else if($act=$works_on){
            $servername = "localhost";
            $username = "root";
            $password = "";
            $db_name = "company";
            
            $con = mysqli_connect($servername,$username,$password,$db_name);
            
          
            
            
            
            echo "<table border='1'>";
            $result = mysqli_query($con, "SELECT * FROM works_on;");
            echo "<td>".'<b>Essn<b>';    "</td>";
            echo "<td>".'<b>Pno<b>';    "</td>";
            echo "<td>".'<b>Hours<b>';    "</td>";            
                while($row = mysqli_fetch_array($result)){
                    echo"<tr>";
                    echo "<td>" . $row['Essn'] . "</td>";
                    echo "<td>" . $row['Pno'] . "</td>";
                    echo "<td>" . $row['Hours'] . "</td>";                   
                    echo "</tr>";
                }
                
                
             echo "</table>";
             
            mysqli_close($con);
        }
        
        ?>
    </body>
</html>

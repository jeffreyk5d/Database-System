<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title></title>
        <meta charset="UTF-8">
        
    </head>
    <body>
        <?php
        $radio1=$_POST['r'];
        echo"血型:$radio1<br>";
        ?>
    </body>
</html>